import numpy as np 
import matplotlib.pyplot as plt
#import networkx as nx


g = np.loadtxt('lau15_dist.txt')
 

print(type(g))
print(g)


